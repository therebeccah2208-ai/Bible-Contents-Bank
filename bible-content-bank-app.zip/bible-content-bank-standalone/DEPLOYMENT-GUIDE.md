# 🚀 Bible Content Bank — Deployment Guide

How to turn your Bible Content Bank into a standalone app anyone can access,
without going through Claude.ai.

---

## WHAT YOU NEED BEFORE YOU START

- [ ] A free **GitHub** account → github.com
- [ ] A free **Vercel** account → vercel.com (sign up with GitHub)
- [ ] An **Anthropic API key** → console.anthropic.com
- [ ] The app files (included in this download)

Estimated time: **15–20 minutes**

---

## STEP 1 — GET YOUR ANTHROPIC API KEY

1. Go to **console.anthropic.com** and sign in (or create a free account)
2. Click **"API Keys"** in the left sidebar
3. Click **"Create Key"** → give it a name like "Bible Content Bank"
4. **Copy the key** — it starts with `sk-ant-...`
5. Save it somewhere safe. You'll need it in Step 4.

> ⚠️ Note: Anthropic API usage costs a small amount per generation (~$0.01–0.03
> per full content bank). You'll need to add a payment method on the console.
> New accounts get free credits to start.

---

## STEP 2 — UPLOAD THE CODE TO GITHUB

### Option A — Using GitHub's website (easiest, no coding needed)

1. Go to **github.com** and sign in
2. Click the **"+"** icon (top right) → **"New repository"**
3. Name it: `bible-content-bank`
4. Make it **Public** or **Private** (both work)
5. Click **"Create repository"**
6. On the next page, click **"uploading an existing file"**
7. Drag and drop ALL the files from your downloaded folder:
   ```
   bible-content-bank-standalone/
   ├── index.html
   ├── package.json
   ├── vite.config.js
   └── src/
       ├── App.jsx
       └── main.jsx
   ```
   > Important: Upload the files INSIDE the folder, not the folder itself.
   > Upload index.html, package.json, vite.config.js, and the src folder contents.
8. Scroll down → Click **"Commit changes"**

### Option B — Using Bolt.new (even easier, skip GitHub entirely)

1. Go to **bolt.new**
2. Click **"Import from file"** or paste the App.jsx code directly
3. Bolt will auto-setup everything — skip to Step 4

---

## STEP 3 — DEPLOY TO VERCEL

1. Go to **vercel.com** and click **"Sign Up"** → choose **"Continue with GitHub"**
2. Once signed in, click **"Add New Project"**
3. Find your `bible-content-bank` repository and click **"Import"**
4. Vercel will auto-detect it as a Vite/React project
5. Under **"Framework Preset"** make sure **Vite** is selected
6. Click **"Deploy"** — wait about 1 minute

After deploying, you'll get a live URL like:
`https://bible-content-bank-yourname.vercel.app`

---

## STEP 4 — ADD YOUR API KEY (IMPORTANT!)

Your API key must be added as an **environment variable** so it stays secret
and isn't visible in your code.

1. In Vercel, go to your project dashboard
2. Click **"Settings"** → **"Environment Variables"**
3. Add a new variable:
   - **Name:** `VITE_ANTHROPIC_API_KEY`
   - **Value:** your API key (`sk-ant-...`)
   - **Environment:** select All (Production, Preview, Development)
4. Click **"Save"**
5. Go back to your project and click **"Redeploy"** → **"Redeploy"** (to apply the key)

> 🔒 This keeps your API key hidden from users visiting your app.

---

## STEP 5 — VISIT YOUR LIVE APP

After redeployment (takes ~1 minute):

1. Go back to your Vercel project overview
2. Click the **live URL** at the top
3. Your Bible Content Bank is now live! 🎉

Share this URL with anyone — they can use the app directly without
going through Claude.ai.

---

## OPTIONAL — USE A CUSTOM DOMAIN

Want a branded URL like `www.biblecontentbank.com`?

1. Buy a domain on **Namecheap** or **Google Domains** (~$10–15/year)
2. In Vercel → Settings → Domains → Add your domain
3. Follow Vercel's instructions to point your domain to their servers
4. Done! Your app will be live on your own custom URL.

---

## TROUBLESHOOTING

**"API key not working"**
→ Make sure the key starts with `sk-ant-` and was saved correctly in Vercel environment variables. Redeploy after adding.

**"Build failed on Vercel"**
→ Make sure all 5 files were uploaded to GitHub correctly (index.html, package.json, vite.config.js, src/App.jsx, src/main.jsx)

**"Content not generating"**
→ Check your Anthropic account has billing set up at console.anthropic.com

**"I want users to have their own API keys"**
→ The app includes an API key input screen — if no environment variable is set, users can enter their own key directly in the app.

---

## QUICK REFERENCE — FILE STRUCTURE

```
your-github-repo/
├── index.html              ← App entry point
├── package.json            ← Dependencies list
├── vite.config.js          ← Build config
└── src/
    ├── main.jsx            ← React bootstrap
    └── App.jsx             ← Full app code (edit this to customize)
```

---

## WANT TO CUSTOMIZE THE APP?

Open `src/App.jsx` and look for these easy edits:

- **Add more characters:** Find the `CHARACTERS` array at the top and add names
- **Change the prompts:** Find the `getPrompt()` function to edit what AI generates
- **Change colors:** Search for `#d4af37` (gold) and `#0f0c1d` (dark bg) to restyle

---

*Built with React + Vite + Anthropic Claude API*
*Deployment powered by Vercel (free tier)*
